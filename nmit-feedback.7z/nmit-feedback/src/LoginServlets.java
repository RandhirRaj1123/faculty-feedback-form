import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.randhir.domain.Student;
import com.randhir.jdbc.JdbcWrapper;

/**
 * @author Raj Randhir
 *
 */
@WebServlet("/login")
public class LoginServlets extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8293763349379090837L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		String usn = req.getParameter("usn");
		String password = req.getParameter("password");
		JdbcWrapper db = new JdbcWrapper();
		List<Student> list = db.getStudentByUsnAndPassword(usn, password);
		if (list != null && !list.isEmpty()) {
			HttpSession session = req.getSession(true);
			session.setAttribute("USN", usn);
			out.println("<h1>" + " u have logged in successfully." + "</h1>");
			resp.sendRedirect("feedback_form.html");
		} else {
			out.println("<h1>" + "failed" + "</h1>");
		}
	}

	@Override
	public void destroy() {
		super.destroy();
	}

	@Override
	public void init() throws ServletException {
		super.init();
	}
}
