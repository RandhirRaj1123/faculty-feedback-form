package com.randhir.domain;

/**
 * @author Raj Randhir
 *
 */
public class Student {

	private String usn;
	private String name;
	private String password;

	public Student(String usn, String name, String password) {
		super();
		this.usn = usn;
		this.name = name;
		this.password = password;
	}

	public String getUsn() {
		return usn;
	}

	public void setUsn(String usn) {
		this.usn = usn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Student [usn=" + usn + ", name=" + name + ", password=" + password + "]";
	}

}
