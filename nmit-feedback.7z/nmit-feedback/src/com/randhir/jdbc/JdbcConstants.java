package com.randhir.jdbc;

/**
 * @author Raj Randhir
 *
 */
public interface JdbcConstants {
	public static final String URL = "jdbc:mysql://localhost:8080/feedback";
	public static final String USERNAME = "root";
	public static final String PASSWORD = "password";
}
