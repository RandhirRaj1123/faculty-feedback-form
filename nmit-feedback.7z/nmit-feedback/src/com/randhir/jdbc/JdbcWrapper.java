package com.randhir.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.randhir.domain.Student;

/**
 * @author Raj Randhir
 *
 */
public class JdbcWrapper {

	private Connection conn;
	private Statement stmt;

	public JdbcWrapper() {
		conn = new ConnectionCheck().getConnection();
		try {
			stmt = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Statement getStmt() {
		return stmt;
	}

	public Connection getConn() {
		return conn;
	}

	public Boolean insertIntoDb(String usn, String name, String password) {
		try {
			getStmt().execute("Insert into student values('" + usn + "','" + name + "','" + password + "');");
			return true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public Boolean insertFeedbackIntoDb(String stdId, String email, String course, String instructorName, String q0,
			String q1, String q2, String q3, String q4, String q5, String q6, String q7, String q8, String q9,
			String q10, String q11) {
		try {
			getStmt().execute("Insert into feedback_form  values('" + stdId + "','" + email + "','" + course + "','"
					+ instructorName + "','" + q0 + "','" + q1 + "','" + q2 + "','" + q3 + "','" + q4 + "','" + q5
					+ "','" + q6 + "','" + q7 + "','" + q8 + "','" + q9 + "','" + q10 + "','" + q11 + "');");
			return true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public List<Student> getStudentByUsnAndPassword(String usn, String password) {
		try {
			String query = "select * from student where usn=" + "'" + usn + "'" + " and password=" + "'" + password
					+ "'";
			System.out.println("query passed is " + query);
			return mapper(getStmt().executeQuery(query));

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	public List<Student> mapper(ResultSet result) {

		List<Student> stdList = new ArrayList<Student>();
		try {
			while (result.next()) {
				String usn = result.getString("usn");
				String name = result.getString("name");
				String password = result.getString("password");
				stdList.add(new Student(usn, name, password));
			}
			System.out.println(stdList);
			return stdList;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
