import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.randhir.jdbc.JdbcWrapper;

/**
 * @author Raj Randhir
 *
 */
@WebServlet("/feedback")
public class FeedbackServlets extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8293763349379090837L;

	@Override
	public void destroy() {
		super.destroy();
	}

	@Override
	public void init() throws ServletException {
		super.init();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		String stdId = req.getParameter("q3_studentId");
		String email = req.getParameter("q4_studentEmail");
		String course = req.getParameter("q5_course");
		String instructorName = req.getParameter("q6_instructorName");
		String q0 = req.getParameter("q7_instructorFeedback[0]");
		String q1 = req.getParameter("q7_instructorFeedback[1]");
		String q2 = req.getParameter("q7_instructorFeedback[2]");
		String q3 = req.getParameter("q7_instructorFeedback[3]");
		String q4 = req.getParameter("q7_instructorFeedback[4]");
		String q5 = req.getParameter("q7_instructorFeedback[5]");
		String q6 = req.getParameter("q7_instructorFeedback[6]");
		String q7 = req.getParameter("q7_instructorFeedback[7]");
		String q8 = req.getParameter("q7_instructorFeedback[8]");
		String q9 = req.getParameter("q7_instructorFeedback[9]");
		String q10 = req.getParameter("q7_instructorFeedback[10]");
		String q11 = req.getParameter("q7_instructorFeedback[11]");
		JdbcWrapper jdbc = new JdbcWrapper();
		boolean isTrue = jdbc.insertFeedbackIntoDb(stdId, email, course, instructorName, q0, q1, q2, q3, q4, q5, q6, q7,
				q8, q9, q10, q11);
		if (isTrue) {
			out.println("Thanks a lot!!");
			resp.sendRedirect("finish.html");
		} else {
			out.print("oops something went wrong!!");
		}
	}

}
