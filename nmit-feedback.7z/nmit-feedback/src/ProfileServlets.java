import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.randhir.jdbc.JdbcWrapper;

/**
 * @author Raj Randhir
 *
 */
@WebServlet("/profile")
public class ProfileServlets extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -481668003179621805L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		String usn = req.getParameter("usn");
		String name = req.getParameter("name");
		String password = req.getParameter("password");
		JdbcWrapper db = new JdbcWrapper();
		boolean isCreated = db.insertIntoDb(usn, name, password);
		System.out.println("value returned from db is" + isCreated);
		if (isCreated) {
			out.println("<h1>" + " u have successfully added the login name and password." + "</h1>");
			resp.sendRedirect("index.html");
		} else {
			out.println("<h1>" + "something went wrong while registering the user!! " + "</h1>");
		}
	}

	@Override
	public void destroy() {
		super.destroy();
	}

	@Override
	public void init() throws ServletException {
		super.init();
	}
}
