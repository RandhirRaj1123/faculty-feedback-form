import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * @author Raj Randhir
 *
 */
@WebServlet("/home")
public class HomeServlets extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8293763349379090837L;

	@Override
	public void destroy() {
		super.destroy();
	}

	@Override
	public void init() throws ServletException {
		super.init();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(true);
		String usn = String.valueOf(session.getAttribute("USN"));
		PrintWriter out = resp.getWriter();
		out.print("<h1> Welcome " + usn + "</h1>");
		out.println("<html><head>");
		out.print("<link rel='stylesheet' href='table.css'>");
		out.println("</head><body>");
		out.print("<div id='demo'>" + "<h1>Material Design Responsive Table</h1>"
				+ "<h2>Table of my other Material Design works (list was updated 08.2015)</h2>"
				+ "<div class='table-responsive-vertical shadow-z-1'>"
				+ " <table id='table' class='table table-hover table-mc-light-blue'>" + "<thead>" + " <tr>"
				+ "  <th>ID</th>" + "   <th>Name</th>" + "   <th>Link</th>" + "  <th>Status</th>" + "   </tr>"
				+ "  </thead>" + "  <tbody>" + " <tr>" + "  <td data-title='ID'>1</td>"
				+ "   <td data-title='Name'>Material Design Color Palette</td>" + " <td data-title='Link'>"
				+ "  <a href='feedback_form.html' target='_blank'>click here</a>" + " </td>"
				+ "  <td data-title='Status'>Completed</td>" + "  </tr>" + " </tbody>" + " </table>" + "</div>");
		out.println("</body></html>");
	}
}
